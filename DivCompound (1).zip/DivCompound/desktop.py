"""
DivCompound — Windows desktop launcher.

Runs the Flask backend on a background thread and shows the UI in a native
window (Microsoft Edge WebView2 via pywebview). No browser or console needed.

Dev run:   python desktop.py
Build exe: build.bat   (see README-WINDOWS.md)
"""
from __future__ import annotations

import ctypes
import os
import socket
import sys
import threading
import time
import urllib.request

import webview  # pywebview

from server import app

APP_NAME = "DivCompound"
# A FIXED port matters: browser storage (your saved portfolio) is tied to the
# origin http://127.0.0.1:<port>. Changing the port would "lose" saved data.
PORT = 47850
URL = f"http://127.0.0.1:{PORT}/"


def data_dir() -> str:
    """Per-user folder for WebView2 profile (holds localStorage) and logs."""
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    path = os.path.join(base, APP_NAME)
    os.makedirs(path, exist_ok=True)
    return path


def message_box(text: str, title: str = APP_NAME) -> None:
    if sys.platform == "win32":
        ctypes.windll.user32.MessageBoxW(0, text, title, 0x40)
    else:
        print(f"{title}: {text}")


def port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) == 0


def is_our_server() -> bool:
    try:
        with urllib.request.urlopen(URL + "api/ping", timeout=1) as r:
            return b"DivCompound" in r.read()
    except Exception:
        return False


def run_server() -> None:
    from werkzeug.serving import make_server
    make_server("127.0.0.1", PORT, app, threaded=True).serve_forever()


def wait_until_up(timeout: float = 15) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if is_our_server():
            return True
        time.sleep(0.1)
    return False


def main() -> None:
    # Redirect output when frozen without a console (windowed exe has no stdout)
    if getattr(sys, "frozen", False):
        log = open(os.path.join(data_dir(), "divcompound.log"), "a", buffering=1, encoding="utf-8")
        sys.stdout = sys.stderr = log

    if port_in_use(PORT):
        if is_our_server():
            message_box("DivCompound is already running.")
        else:
            message_box(f"Port {PORT} is being used by another program.\nClose it and try again.")
        return

    threading.Thread(target=run_server, daemon=True).start()
    if not wait_until_up():
        message_box("The DivCompound engine failed to start. See divcompound.log in %LOCALAPPDATA%\\DivCompound.")
        return

    webview.settings["ALLOW_DOWNLOADS"] = True            # CSV / JSON exports
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True

    webview.create_window(
        APP_NAME + " — Dividend & Compound Growth Studio",
        URL,
        width=1480, height=940, min_size=(1100, 700),
        background_color="#0b1020",
        text_select=True,
    )
    webview.start(
        private_mode=False,                                  # persist localStorage between launches
        storage_path=os.path.join(data_dir(), "webview"),
        icon=os.path.join(getattr(sys, "_MEIPASS", os.path.dirname(__file__)), "assets", "icon.png"),
    )


if __name__ == "__main__":
    main()
