"""
DivCompound — Dividend & Compound Growth Studio
Backend: lightweight Flask server that proxies & analyses Yahoo Finance market data.

Endpoints
  GET /api/quote/<symbol>         live quote + dividend analytics + growth estimates
  GET /api/history/<symbol>?start=YYYY-MM-DD   daily closes + dividends (for backtests)
  GET /                           single-page application

Run:  python server.py   ->  http://127.0.0.1:8050
"""
from __future__ import annotations

import math
import os
import statistics
import threading
import time
from datetime import datetime, timezone, date

import requests
from flask import Flask, jsonify, request, send_from_directory

import sys
# When frozen by PyInstaller, bundled files live in sys._MEIPASS
APP_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
app = Flask(__name__, static_folder=os.path.join(APP_DIR, "static"), static_url_path="/static")

YAHOO = "https://query1.finance.yahoo.com/v8/finance/chart/{sym}"
HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                         "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"}
QUOTE_TTL = 60          # seconds – live price cache
HISTORY_TTL = 6 * 3600  # seconds – long history cache

_cache: dict[str, tuple[float, object]] = {}
_lock = threading.Lock()
_session = requests.Session()
_session.headers.update(HEADERS)


class DataError(Exception):
    pass


def _cached(key: str, ttl: int, fn):
    now = time.time()
    with _lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < ttl:
            return hit[1]
    val = fn()
    with _lock:
        _cache[key] = (now, val)
    return val


def _fetch_chart(sym: str, rng: str, interval: str) -> dict:
    params = {"interval": interval, "events": "div,split", "includeAdjustedClose": "true"}
    if rng == "max":  # range=max silently downgrades granularity; explicit periods keep daily bars
        params.update(period1=0, period2=int(time.time()) + 86400)
    else:
        params["range"] = rng
    last_err = None
    for host in ("query1", "query2"):
        try:
            r = _session.get(YAHOO.replace("query1", host).format(sym=sym), params=params, timeout=15)
            if r.status_code == 404:
                raise DataError(f"Symbol '{sym}' not found")
            r.raise_for_status()
            js = r.json()
            err = js.get("chart", {}).get("error")
            if err:
                raise DataError(err.get("description") or f"No data for '{sym}'")
            res = js["chart"]["result"]
            if not res:
                raise DataError(f"No data for '{sym}'")
            return res[0]
        except DataError:
            raise
        except Exception as e:  # network / rate limit -> try backup host
            last_err = e
    raise DataError(f"Market data unavailable for '{sym}': {last_err}")


def _dividends(res: dict) -> list[dict]:
    divs = (res.get("events") or {}).get("dividends") or {}
    out = []
    for v in divs.values():
        d = datetime.fromtimestamp(v["date"], tz=timezone.utc).date()
        out.append({"date": d.isoformat(), "amount": round(float(v["amount"]), 6)})
    out.sort(key=lambda x: x["date"])
    return out


def _cagr(start: float, end: float, years: float):
    if not start or not end or start <= 0 or end <= 0 or years <= 0:
        return None
    return (end / start) ** (1 / years) - 1


def _analyse(sym: str) -> dict:
    # Daily history is required: Yahoo drops dividend events on monthly bars.
    res = _cached(f"h:{sym}", HISTORY_TTL, lambda: _fetch_chart(sym, "max", "1d"))
    meta = res.get("meta", {})
    ts = res.get("timestamp") or []
    closes = (res.get("indicators", {}).get("quote") or [{}])[0].get("close") or []
    monthly_map = {}
    for t, c in zip(ts, closes):
        if c:
            d = datetime.fromtimestamp(t, tz=timezone.utc).date()
            monthly_map[(d.year, d.month)] = (d, c)   # last close of each month
    monthly = [monthly_map[k] for k in sorted(monthly_map)]

    price = meta.get("regularMarketPrice") or (monthly[-1][1] if monthly else None)
    if not price:
        raise DataError(f"No price for '{sym}'")

    # day change comes from a short daily request (monthly meta prevClose is month-based)
    prev_close = None
    try:
        d = _fetch_chart(sym, "5d", "1d")
        dc = [c for c in (d.get("indicators", {}).get("quote") or [{}])[0].get("close") or [] if c]
        if len(dc) >= 2:
            prev_close = dc[-2]
        meta = {**meta, **{k: v for k, v in d.get("meta", {}).items() if v is not None}}
        price = meta.get("regularMarketPrice") or price
    except DataError:
        pass

    divs = _dividends(res)
    today = date.today()
    one_year_ago = today.replace(year=today.year - 1)
    ttm = [x for x in divs if date.fromisoformat(x["date"]) > one_year_ago]
    ttm_sum = sum(x["amount"] for x in ttm)

    # payment frequency (from last 2 years to smooth out timing jitter)
    two_years_ago = today.replace(year=today.year - 2)
    n2 = len([x for x in divs if date.fromisoformat(x["date"]) > two_years_ago])
    freq = 0
    if divs:
        raw = n2 / 2 if n2 else len(ttm)
        freq = min((1, 2, 4, 12, 52), key=lambda f: abs(f - raw)) if raw > 0 else 0

    # forward rate: latest regular payment * frequency (specials filtered by median)
    forward = 0.0
    last_amt = 0.0
    if ttm and freq:
        amts = [x["amount"] for x in ttm]
        med = statistics.median(amts)
        regular = [a for a in amts if a <= med * 1.75]
        last_amt = regular[-1] if regular else amts[-1]
        if freq >= 12 and regular:   # monthly/weekly payers vary: use the TTM regular average
            last_amt = sum(regular) / len(regular)
        forward = last_amt * freq
    elif divs and freq:
        forward = ttm_sum

    # Payment calendar: month/day pattern of the most recent `freq` payments
    schedule = []
    if freq and divs and freq <= 12:
        recent = divs[-int(freq):]
        schedule = sorted({(date.fromisoformat(x["date"]).month, date.fromisoformat(x["date"]).day) for x in recent})
        schedule = [{"month": m, "day": dd} for m, dd in schedule]

    # Dividend growth using full calendar years
    annual: dict[int, float] = {}
    for x in divs:
        y = int(x["date"][:4])
        annual[y] = annual.get(y, 0) + x["amount"]
    full_years = sorted(y for y in annual if y < today.year)
    # drop first year if it is partial (company/fund started paying mid-year)
    if len(full_years) > 1 and divs and divs[0]["date"][:4] == str(full_years[0]):
        cnt_first = len([x for x in divs if x["date"].startswith(str(full_years[0]))])
        cnt_next = len([x for x in divs if x["date"].startswith(str(full_years[1]))])
        if cnt_first < cnt_next:
            full_years = full_years[1:]

    def div_cagr(n):
        if len(full_years) < n + 1:
            return None
        end_y = full_years[-1]
        start_y = end_y - n
        if start_y not in annual:
            return None
        return _cagr(annual[start_y], annual[end_y], n)

    def price_cagr(n):
        if not monthly:
            return None
        target = today.replace(year=today.year - n)
        older = [p for p in monthly if p[0] <= target]
        if not older:
            return None
        return _cagr(older[-1][1], price, n)

    growth = {
        "div3": div_cagr(3), "div5": div_cagr(5), "div10": div_cagr(10),
        "price3": price_cagr(3), "price5": price_cagr(5), "price10": price_cagr(10),
    }

    def pick(*keys):
        for k in keys:
            if growth.get(k) is not None:
                return growth[k]
        return None

    # Suggested assumptions: blend 5y/10y (where available), clamp to sane bounds
    dg = [g for g in (growth["div5"], growth["div10"]) if g is not None] or \
         [g for g in (growth["div3"],) if g is not None]
    pg = [g for g in (growth["price5"], growth["price10"]) if g is not None] or \
         [g for g in (growth["price3"],) if g is not None]
    clamp = lambda v, lo, hi: max(lo, min(hi, v))
    suggested_div = clamp(sum(dg) / len(dg), -0.10, 0.15) if dg else 0.0
    suggested_price = clamp(sum(pg) / len(pg), -0.10, 0.15) if pg else 0.05

    return {
        "symbol": sym.upper(),
        "name": meta.get("longName") or meta.get("shortName") or sym.upper(),
        "currency": meta.get("currency", "USD"),
        "exchange": meta.get("fullExchangeName") or meta.get("exchangeName"),
        "type": meta.get("instrumentType"),
        "price": price,
        "prevClose": prev_close,
        "high52": meta.get("fiftyTwoWeekHigh"),
        "low52": meta.get("fiftyTwoWeekLow"),
        "marketTime": meta.get("regularMarketTime"),
        "dividends": divs,
        "ttmDividend": round(ttm_sum, 6),
        "forwardDividend": round(forward, 6),
        "lastDividend": last_amt,
        "lastExDate": divs[-1]["date"] if divs else None,
        "frequency": freq,
        "schedule": schedule,
        "annualDividends": [{"year": y, "amount": round(annual[y], 6)} for y in sorted(annual)],
        "growth": growth,
        "priceHistory": [[d.isoformat(), round(c, 4)] for d, c in monthly],
        "suggested": {"divGrowth": suggested_div, "priceGrowth": suggested_price},
        "fetchedAt": int(time.time()),
    }


@app.get("/api/quote/<symbol>")
def quote(symbol):
    sym = symbol.strip().upper()
    if not sym or len(sym) > 15:
        return jsonify({"error": "Invalid symbol"}), 400
    try:
        return jsonify(_cached(f"q:{sym}", QUOTE_TTL, lambda: _analyse(sym)))
    except DataError as e:
        return jsonify({"error": str(e)}), 404


@app.get("/api/history/<symbol>")
def history(symbol):
    sym = symbol.strip().upper()
    start = request.args.get("start", "")
    try:
        res = _cached(f"h:{sym}", HISTORY_TTL, lambda: _fetch_chart(sym, "max", "1d"))
    except DataError as e:
        return jsonify({"error": str(e)}), 404
    ts = res.get("timestamp") or []
    closes = (res.get("indicators", {}).get("quote") or [{}])[0].get("close") or []
    rows = [(datetime.fromtimestamp(t, tz=timezone.utc).date().isoformat(), round(c, 4))
            for t, c in zip(ts, closes) if c]
    if start:
        rows = [r for r in rows if r[0] >= start]
    divs = [d for d in _dividends(res) if not start or d["date"] >= start]
    return jsonify({"symbol": sym, "dates": [r[0] for r in rows], "closes": [r[1] for r in rows],
                    "dividends": divs})


@app.get("/api/ping")
def ping():
    return jsonify({"app": "DivCompound", "ok": True})


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8050))
    print(f"\n  DivCompound running ->  http://127.0.0.1:{port}\n")
    app.run(host="127.0.0.1", port=port, debug=False)
