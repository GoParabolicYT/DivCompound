# DivCompound — Dividend & Compound Growth Studio

A web app for tracking dividend income and projecting how a portfolio could compound.

## Quick start
```
pip install -r requirements.txt
python server.py        # then open http://127.0.0.1:8050
```
(or double-click `run.bat` on Windows / `./run.sh` on macOS/Linux)

## Features
| Page | What it does |
|---|---|
| **Dashboard** | Live prices, day change, market value, cost basis, unrealized P&L, forward annual income, yield, yield-on-cost, sortable holdings, 12-month income chart, allocation donut, upcoming dividend calendar |
| **Projections** | 5/10/15/20/25-year milestones: value, annual and monthly income, yield on cost. Shows DRIP vs No-DRIP side by side. Contribution plan: amount, frequency (weekly, bi-weekly, twice-monthly, monthly, quarterly, annual), exact day of month or weekday, start date, yearly step-up, weekend roll-forward, and how each contribution is split. Growth assumptions for each holding can be overridden |
| **Contribution Ledger** | Every simulated purchase: date, estimated price, shares bought, running average cost basis, and DRIP buys. Includes a chart and CSV export |
| **What-If Portfolio** | Your current holdings plus hypothetical buys (in dollars or shares), compared with the current portfolio. Can use the same contribution plan or a separate one |
| **Historical Backtest** | Replays a contribution schedule against real daily prices and real dividends. Reports cost basis, ending value, annualized return (XIRR) and a purchase log |
| **Dividend Research** | For any ticker: dividend history, year-over-year growth, growth streak, 3/5/10-year dividend and price CAGR, price chart |
| **Settings** | Dividend tax rate, growth caps, yield-drift guard, auto-refresh, JSON backup/restore, CSV import (`symbol,shares,avg_cost`) |

## Methodology
* **Dividend growth**: CAGR of full calendar-year dividend totals over the last 5 and 10 years, averaged. Falls back to 3 years. Capped at 15% by default.
* **Price appreciation**: price-only CAGR over 5 and 10 years. Capped at ±12% by default. Dividends are modelled separately so they are not counted twice.
* **Payment timing**: each holding follows its historical ex-dividend calendar. The forward rate is the latest regular payment × frequency. Monthly payers use the trailing-12-month regular average. Special dividends are excluded.
* **Simulation**: runs day by day. Contributions buy at the projected price on that exact date. DRIP reinvests after-tax dividends on the payment date. Without DRIP, dividends build up as cash.
* **Yield-drift guard**: limits each holding's projected yield to 2× today's yield. Without it, compounding becomes unrealistic when dividend growth is far above price growth.

## Architecture
* `server.py`: Flask app. Proxies Yahoo Finance's chart API. Market data is cached in memory: 60 s for live quotes, 6 h for history. Dividend analysis runs on the server.
* `static/index.html`, `static/styles.css`, `static/app.js`: the frontend, plain JavaScript with no build step. The projection engine runs in the browser so results update instantly. Chart.js is bundled locally.
* Data is stored in the browser's localStorage. Use Export/Import to move it between devices.

## Production notes
* Yahoo's chart endpoint is unofficial and rate-limited. For a commercial release, use a licensed data provider such as Polygon, Tiingo, IEX or EODHD. Only `_fetch_chart` in `server.py` needs to change.
* Use a WSGI server for deployment (`gunicorn -w 2 server:app`). The dev server binds to 127.0.0.1 only.
* Add user accounts and server-side storage if portfolios need to sync across devices.
* Projections are estimates, not financial advice. Keep the disclaimer visible.
