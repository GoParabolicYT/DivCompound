@echo off
REM ==========================================================
REM  DivCompound - Windows build script
REM  Produces:  dist\DivCompound\DivCompound.exe
REM             installer\Output\DivCompound-Setup-1.0.0.exe (if Inno Setup installed)
REM ==========================================================
setlocal
cd /d %~dp0

echo [1/4] Creating virtual environment...
if not exist .venv python -m venv .venv || goto :err
call .venv\Scripts\activate.bat

echo [2/4] Installing dependencies...
python -m pip install --upgrade pip >nul
python -m pip install -r requirements-desktop.txt || goto :err

echo [3/4] Building DivCompound.exe ...
pyinstaller --noconfirm --clean DivCompound.spec || goto :err
echo     -> dist\DivCompound\DivCompound.exe

echo [4/4] Building installer...
if not exist installer\MicrosoftEdgeWebview2Setup.exe (
  powershell -NoProfile -Command "Invoke-WebRequest https://go.microsoft.com/fwlink/p/?LinkId=2124703 -OutFile installer\MicrosoftEdgeWebview2Setup.exe"
)
set ISCC="%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist %ISCC% (
  %ISCC% installer\DivCompound.iss || goto :err
  echo     -> installer\Output\DivCompound-Setup-1.0.0.exe
) else (
  echo     Inno Setup 6 not found - skipping installer.
  echo     Install it from https://jrsoftware.org/isdl.php  or run:  winget install JRSoftware.InnoSetup
)
echo.
echo Build complete.
pause
exit /b 0

:err
echo.
echo BUILD FAILED - see messages above.
pause
exit /b 1
