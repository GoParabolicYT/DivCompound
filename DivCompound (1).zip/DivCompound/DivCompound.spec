# PyInstaller spec — builds dist\DivCompound\DivCompound.exe (one-folder, fast start)
# Usage: pyinstaller --noconfirm DivCompound.spec
block_cipher = None

a = Analysis(
    ["desktop.py"],
    pathex=[],
    binaries=[],
    datas=[("static", "static"), ("assets", "assets")],
    hiddenimports=["webview.platforms.edgechromium", "webview.platforms.winforms", "clr_loader", "pythonnet"],
    excludes=["tkinter", "pandas", "numpy", "matplotlib", "PIL", "pytest"],
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="DivCompound",
    icon="assets/icon.ico",
    console=False,            # windowed app: no black console window
    upx=False,                # UPX triggers antivirus false positives
    version="version_info.txt",
)
coll = COLLECT(exe, a.binaries, a.zipfiles, a.datas, strip=False, upx=False, name="DivCompound")
