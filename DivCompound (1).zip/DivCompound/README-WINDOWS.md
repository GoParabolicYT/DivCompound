# Building DivCompound as a Windows app

The app opens in its own native window, using Microsoft Edge WebView2 (built into Windows 10/11).
No browser tab, no console window. The Flask engine runs hidden inside the exe.

## Option A: build on a Windows PC
1. Install **Python 3.11+** from python.org. Tick "Add Python to PATH".
2. Optional, needed for the installer: install **Inno Setup 6** (`winget install JRSoftware.InnoSetup`).
3. Double-click **`build.bat`**.

Output:
* `dist\DivCompound\DivCompound.exe` is the portable app. Zip the whole `DivCompound` folder to share it.
* `installer\Output\DivCompound-Setup-1.0.0.exe` is the installer. It adds Start-menu and desktop shortcuts and an uninstaller, and installs WebView2 if it is missing.

## Option B: let GitHub build it, no Windows PC needed
Push this folder to a GitHub repo. Then either open **Actions → Build Windows → Run workflow**, or push a tag like `v1.0.0`.
Download the installer from the run's **Artifacts**.

## Test without building
`pip install -r requirements-desktop.txt` then `python desktop.py`

## Where user data lives
`%LOCALAPPDATA%\DivCompound\` holds the saved portfolio (WebView2 profile) and `divcompound.log`.
Uninstalling keeps this folder, so a reinstall keeps the user's portfolio.

## Before selling
* **Code-sign** both the exe and the installer with a code-signing certificate (an EV certificate avoids SmartScreen warnings).
  Use `signtool sign /fd sha256 /tr http://timestamp.digicert.com /td sha256 /a dist\DivCompound\DivCompound.exe`,
  or add `SignTool=` to the `.iss` file. Unsigned apps show "Windows protected your PC" on first run.
* Change `AppPublisher`, `AppId` (keep it the same for every later version), and the CompanyName in `version_info.txt`.
* Bump the version in `installer\DivCompound.iss` and `version_info.txt` for each release.
* Switch to a licensed market-data provider (see README.md).
