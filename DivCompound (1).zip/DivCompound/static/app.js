/* =====================================================================
   DivCompound — Dividend & Compound Growth Studio  (front-end)
   ---------------------------------------------------------------------
   Sections
     1. Utilities (formatting, dates)
     2. State & persistence
     3. Market data
     4. Simulation engine (projection, contribution schedule, DRIP)
     5. Views: dashboard, projection, ledger, what-if, backtest, research, settings
   ===================================================================== */
"use strict";

/* ---------------------------- 1. UTILITIES ---------------------------- */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uid = () => Math.random().toString(36).slice(2, 10);
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const num = (v, d = 0) => { const n = parseFloat(v); return Number.isFinite(n) ? n : d; };

function money(v, dec = 2) {
  if (v == null || !Number.isFinite(v)) return "—";
  const [i, f] = Math.abs(v).toFixed(dec).split(".");
  const s = i.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + (f ? "." + f : "");
  return (v < 0 ? "-$" : "$") + s;
}
function moneyC(v) { // compact
  if (v == null || !Number.isFinite(v)) return "—";
  const a = Math.abs(v);
  if (a >= 1e9) return (v < 0 ? "-" : "") + "$" + (a / 1e9).toFixed(2) + "B";
  if (a >= 1e6) return (v < 0 ? "-" : "") + "$" + (a / 1e6).toFixed(2) + "M";
  if (a >= 1e5) return (v < 0 ? "-" : "") + "$" + (a / 1e3).toFixed(1) + "K";
  return money(v, a < 100 ? 2 : 0);
}
const pct = (v, dec = 2) => (v == null || !Number.isFinite(v)) ? "—" : (v * 100).toFixed(dec) + "%";
const spct = (v, dec = 2) => (v == null || !Number.isFinite(v)) ? "—" : (v >= 0 ? "+" : "") + (v * 100).toFixed(dec) + "%";
const smoney = (v, dec = 2) => (v >= 0 ? "+" : "") + money(v, dec);
const sdiff = (v, dec = 0) => `<span class="${cls(v)}">${smoney(v, dec)}</span>`;
const sdiffC = v => `<span class="${cls(v)}">${v >= 0 ? "+" : ""}${moneyC(v)}</span>`;
const cls = v => v > 0 ? "pos" : v < 0 ? "neg" : "";
const shares = v => (v == null || !Number.isFinite(v)) ? "—" : v.toLocaleString(undefined, { maximumFractionDigits: 4 });

// Dates are handled as integer "day numbers" (days since epoch, UTC) to avoid timezone drift
const DAY = 864e5;
const dnFromYMD = (y, m, d) => Math.floor(Date.UTC(y, m, d) / DAY);          // m: 0-11
const dnFromISO = s => { const [y, m, d] = s.split("-").map(Number); return dnFromYMD(y, m - 1, d); };
const dnToDate = dn => new Date(dn * DAY);
const isoFromDn = dn => dnToDate(dn).toISOString().slice(0, 10);
const todayDn = () => { const t = new Date(); return dnFromYMD(t.getFullYear(), t.getMonth(), t.getDate()); };
const dim = (y, m) => new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
const weekday = dn => dnToDate(dn).getUTCDay();
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const prettyDate = dn => { const d = dnToDate(dn); return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`; };
const addYearsDn = (dn, k) => { const d = dnToDate(dn); const y = d.getUTCFullYear() + k, m = d.getUTCMonth(); return dnFromYMD(y, m, Math.min(d.getUTCDate(), dim(y, m))); };
const FREQ_LABEL = { 0: "—", 1: "Annual", 2: "Semi-annual", 4: "Quarterly", 12: "Monthly", 52: "Weekly" };

function toast(msg, err = false) {
  const t = $("#toast"); t.textContent = msg; t.className = "toast show" + (err ? " err" : "");
  clearTimeout(toast._t); toast._t = setTimeout(() => t.className = "toast", 3200);
}
function debounce(fn, ms = 250) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
function downloadFile(name, text, type = "text/plain") {
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
const csvRow = arr => arr.map(v => /[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : v).join(",");

/* ------------------------ 2. STATE & PERSISTENCE ----------------------- */
const STORE_KEY = "divcompound.v1";
const defaultPlan = () => ({
  amount: 500, freq: "monthly", dom: 15, weekday: 5, start: isoFromDn(todayDn() + 1),
  stepUp: 0, rollWeekend: true, allocMode: "proportional", weights: {}, lump: 0,
});
const state = {
  holdings: [],             // {id, symbol, shares, avgCost}
  overrides: {},            // symbol -> {dg, pg}  (decimal) manual growth overrides
  plan: defaultPlan(),
  hypo: [],                 // {id, symbol, mode:'dollars'|'shares', amount}
  hypoPlan: defaultPlan(),
  hypoSamePlan: true, hypoDrip: true,
  horizon: 25, dripView: "compare",
  settings: { tax: 0, capDiv: 15, capPrice: 12, yieldCap: 2, auto: false },
  quotes: {},               // symbol -> quote (cached for offline start)
};
function save() {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) { console.warn(e); }
}
function load() {
  try {
    const s = JSON.parse(localStorage.getItem(STORE_KEY) || "null");
    if (s) Object.assign(state, s, { settings: { ...state.settings, ...(s.settings || {}) }, plan: { ...defaultPlan(), ...(s.plan || {}) }, hypoPlan: { ...defaultPlan(), ...(s.hypoPlan || {}) } });
  } catch (e) { console.warn(e); }
}

/* ---------------------------- 3. MARKET DATA ---------------------------- */
const inflight = {};
async function fetchQuote(sym) {
  sym = sym.toUpperCase().trim();
  if (inflight[sym]) return inflight[sym];
  inflight[sym] = (async () => {
    const r = await fetch(`/api/quote/${encodeURIComponent(sym)}`);
    const js = await r.json();
    if (!r.ok || js.error) throw new Error(js.error || "Lookup failed");
    state.quotes[sym] = js;
    return js;
  })().finally(() => delete inflight[sym]);
  return inflight[sym];
}
let lastRefresh = null;
async function refreshAll(silent = false) {
  const syms = [...new Set([...state.holdings.map(h => h.symbol), ...state.hypo.map(h => h.symbol)])];
  if (!syms.length) { setLive("No holdings", ""); return; }
  setLive("Updating…", "");
  $("#refreshBtn").disabled = true;
  const res = await Promise.allSettled(syms.map(fetchQuote));
  $("#refreshBtn").disabled = false;
  const failed = syms.filter((s, i) => res[i].status === "rejected");
  lastRefresh = new Date();
  if (failed.length === syms.length) { setLive("Data offline (cached)", "err"); if (!silent) toast("Could not reach market data — showing cached values", true); }
  else {
    setLive("Live · " + lastRefresh.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), "on");
    if (failed.length && !silent) toast("No data for: " + failed.join(", "), true);
  }
  save(); renderAll();
}
function setLive(text, mode) { $("#liveText").textContent = text; $("#liveDot").className = "dot " + mode; }

/** Growth assumptions for a symbol: override > historical blend (capped) */
function growthFor(sym) {
  const q = state.quotes[sym]; const o = state.overrides[sym] || {};
  const capD = state.settings.capDiv / 100, capP = state.settings.capPrice / 100;
  let hd = 0, hp = 0.05;
  if (q) {
    const g = q.growth || {};
    const d = [g.div5, g.div10].filter(x => x != null); const dd = d.length ? d : [g.div3].filter(x => x != null);
    const p = [g.price5, g.price10].filter(x => x != null); const pp = p.length ? p : [g.price3].filter(x => x != null);
    hd = dd.length ? clamp(dd.reduce((a, b) => a + b, 0) / dd.length, -capD, capD) : 0;
    hp = pp.length ? clamp(pp.reduce((a, b) => a + b, 0) / pp.length, -capP, capP) : 0.05;
  }
  return { dg: o.dg ?? hd, pg: o.pg ?? hp, hd, hp, overD: o.dg != null, overP: o.pg != null };
}

/** Build simulation positions from holdings (+ optional hypothetical additions) */
function buildPositions(extra = []) {
  const map = new Map();
  for (const h of state.holdings) {
    const q = state.quotes[h.symbol]; if (!q) continue;
    const p = map.get(h.symbol) || { symbol: h.symbol, shares: 0, cost: 0 };
    p.shares += h.shares; p.cost += h.shares * h.avgCost; map.set(h.symbol, p);
  }
  for (const x of extra) {
    const q = state.quotes[x.symbol]; if (!q) continue;
    const p = map.get(x.symbol) || { symbol: x.symbol, shares: 0, cost: 0 };
    const sh = x.mode === "shares" ? x.amount : x.amount / q.price;
    p.shares += sh; p.cost += sh * q.price; p.added = (p.added || 0) + sh * q.price; map.set(x.symbol, p);
  }
  return [...map.values()].map(p => {
    const q = state.quotes[p.symbol]; const g = growthFor(p.symbol);
    return { ...p, name: q.name, price: q.price, freq: q.frequency, perPay: q.frequency ? q.forwardDividend / q.frequency : 0,
      schedule: q.schedule || [], lastEx: q.lastExDate, dg: g.dg, pg: g.pg };
  });
}

/* ------------------------ 4. SIMULATION ENGINE ------------------------- */
/** Projected ex-dividend dates for a position in (startDn, endDn] */
function dividendDates(p, startDn, endDn) {
  const out = [];
  if (!p.freq || !p.perPay) return out;
  if (p.freq === 52 && p.lastEx) {
    let d = dnFromISO(p.lastEx); while (d <= startDn) d += 7;
    for (; d <= endDn; d += 7) out.push(d);
    return out;
  }
  const y0 = dnToDate(startDn).getUTCFullYear(), y1 = dnToDate(endDn).getUTCFullYear();
  for (let y = y0; y <= y1; y++)
    for (const s of p.schedule) {
      const d = dnFromYMD(y, s.month - 1, Math.min(s.day, dim(y, s.month - 1)));
      if (d > startDn && d <= endDn) out.push(d);
    }
  return out.sort((a, b) => a - b);
}

/** Every contribution date + amount in [startDn, endDn] for a plan */
function contributionDates(plan, startDn, endDn) {
  const out = [];
  if (!plan.amount || plan.freq === "none") return out;
  const s = Math.max(dnFromISO(plan.start || isoFromDn(startDn)), startDn);
  const sd = dnToDate(s); const sy = sd.getUTCFullYear(), sm = sd.getUTCMonth();
  const dayIn = (y, m, d) => dnFromYMD(y, m, d === "last" ? dim(y, m) : Math.min(+d, dim(y, m)));
  const push = d => { if (d >= s && d <= endDn) out.push(d); };
  const f = plan.freq;
  if (f === "weekly" || f === "biweekly") {
    let d = s; while (weekday(d) !== +plan.weekday) d++;
    for (; d <= endDn; d += f === "weekly" ? 7 : 14) push(d);
  } else {
    const step = { monthly: 1, semimonthly: 1, quarterly: 3, annually: 12 }[f] || 1;
    for (let k = 0; ; k += step) {
      const y = sy + Math.floor((sm + k) / 12), m = (sm + k) % 12;
      if (dnFromYMD(y, m, 1) > endDn) break;
      if (f === "semimonthly") {
        const d1 = plan.dom === "last" ? 15 : +plan.dom;
        push(dayIn(y, m, d1)); push(plan.dom === "last" ? dayIn(y, m, "last") : dayIn(y, m, Math.min(d1 + 15, dim(y, m))));
      } else push(dayIn(y, m, plan.dom));
    }
  }
  // roll weekend dates to Monday (market closed)
  const rolled = out.map(d => { if (!plan.rollWeekend) return d; const w = weekday(d); return w === 6 ? d + 2 : w === 0 ? d + 1 : d; })
    .filter(d => d <= endDn).sort((a, b) => a - b);
  return rolled.map(d => ({ dn: d, amount: plan.amount * Math.pow(1 + (plan.stepUp || 0) / 100, Math.floor((d - s) / 365.25)) }));
}

function contributionWeights(plan, pos) {
  const n = pos.length; if (!n) return [];
  let w;
  if (plan.allocMode === "equal") w = pos.map(() => 1);
  else if (plan.allocMode === "custom") w = pos.map(p => Math.max(0, num(plan.weights[p.symbol], 0)));
  else w = pos.map(p => p.shares * p.price);
  let tot = w.reduce((a, b) => a + b, 0);
  if (tot <= 0) { w = pos.map(() => 1); tot = n; }
  return w.map(x => x / tot);
}

/**
 * Day-by-day projection.
 * Returns yearly snapshots (0..years) and optional purchase ledger.
 */
function simulate(positions, plan, { years = 25, drip = true, tax = 0, ledger = false } = {}) {
  const s = todayDn(), end = addYearsDn(s, years);
  const P = positions.map(p => ({ ...p, sh: p.shares, cb: p.cost }));
  const w = contributionWeights(plan, P);
  const priceAt = (i, t) => P[i].price * Math.pow(1 + P[i].pg, t);
  // Yield-drift guard: dividend/share may not push the yield above N× today's yield
  const yMult = state.settings.yieldCap;
  const dpsAt = (i, t) => {
    const raw = P[i].perPay * Math.pow(1 + P[i].dg, t);
    return yMult > 0 ? Math.min(raw, priceAt(i, t) * (P[i].perPay / P[i].price) * yMult) : raw;
  };

  const contribs = new Map(contributionDates(plan, s + 1, end).map(c => [c.dn, c.amount]));
  const divs = new Map();
  P.forEach((p, i) => dividendDates(p, s, end).forEach(d => { if (!divs.has(d)) divs.set(d, []); divs.get(d).push(i); }));
  const anniv = new Map(); for (let k = 1; k <= years; k++) anniv.set(addYearsDn(s, k), k);

  const initialCost = P.reduce((a, p) => a + p.cb, 0);
  let contributed = 0, cash = 0, divYear = 0, divTotal = 0, dripYear = 0;
  const log = [];
  const snap = (k, dn) => {
    const t = (dn - s) / 365.25;
    const value = P.reduce((a, p, i) => a + p.sh * priceAt(i, t), 0) + cash;
    const fwd = P.reduce((a, p, i) => a + p.sh * dpsAt(i, t) * p.freq, 0) * (1 - tax);
    const invested = initialCost + contributed;
    return { year: k, dn, value, cash, contributed, invested, divYear, divTotal, dripYear, fwd, yoc: invested ? fwd / invested : 0,
      positions: P.map((p, i) => ({ symbol: p.symbol, shares: p.sh, avgCost: p.sh ? p.cb / p.sh : 0, price: priceAt(i, t), value: p.sh * priceAt(i, t), income: p.sh * dpsAt(i, t) * p.freq * (1 - tax) })) };
  };
  const snaps = [snap(0, s)];

  for (let dn = s + 1; dn <= end; dn++) {
    const t = (dn - s) / 365.25;
    const amt = contribs.get(dn);
    if (amt) {
      contributed += amt;
      P.forEach((p, i) => {
        const a = amt * w[i]; if (a <= 0) return;
        const px = priceAt(i, t), sh = a / px; p.sh += sh; p.cb += a;
        if (ledger) log.push({ dn, sym: p.symbol, type: "buy", price: px, shares: sh, amount: a, total: p.sh, avg: p.cb / p.sh });
      });
    }
    const dl = divs.get(dn);
    if (dl) for (const i of dl) {
      const p = P[i]; const net = p.sh * dpsAt(i, t) * (1 - tax);
      if (net <= 0) continue;
      divYear += net; divTotal += net;
      if (drip) {
        const px = priceAt(i, t), sh = net / px; p.sh += sh; p.cb += net; dripYear += net;
        if (ledger) log.push({ dn, sym: p.symbol, type: "drip", price: px, shares: sh, amount: net, total: p.sh, avg: p.cb / p.sh });
      } else cash += net;
    }
    const k = anniv.get(dn);
    if (k) { snaps.push(snap(k, dn)); divYear = 0; dripYear = 0; }
  }
  return { snaps, ledger: log, start: s, initialCost };
}

/* ------------------------------ CHARTS ------------------------------ */
const charts = {};
const PALETTE = ["#10b981", "#38bdf8", "#a78bfa", "#fbbf24", "#f472b6", "#22d3ee", "#fb923c", "#84cc16", "#e879f9", "#60a5fa", "#f87171", "#2dd4bf"];
Chart.defaults.color = "#8c9bba";
Chart.defaults.font.family = "Inter, 'Segoe UI', system-ui, sans-serif";
Chart.defaults.borderColor = "rgba(34,48,79,.6)";
function chart(id, cfg) {
  if (charts[id]) charts[id].destroy();
  const el = document.getElementById(id); if (!el) return;
  cfg.options = Object.assign({ responsive: true, maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
    plugins: { legend: { labels: { usePointStyle: true, boxWidth: 8, padding: 14 } }, tooltip: { backgroundColor: "#0f172a", borderColor: "#2b3b60", borderWidth: 1, padding: 10 } } }, cfg.options || {});
  charts[id] = new Chart(el, cfg);
}
const moneyAxis = { ticks: { callback: v => moneyC(v) }, grid: { color: "rgba(34,48,79,.5)" } };
const ttMoney = { callbacks: { label: c => `${c.dataset.label}: ${money(c.parsed.y)}` } };
function gradientFill(ctxId, color) {
  const c = document.getElementById(ctxId).getContext("2d"); const g = c.createLinearGradient(0, 0, 0, 320);
  g.addColorStop(0, color + "55"); g.addColorStop(1, color + "00"); return g;
}
const kpi = (label, value, sub = "", extra = "") => `<div class="kpi ${extra}"><div class="kpi-l">${label}</div><div class="kpi-v">${value}</div><div class="kpi-s">${sub}</div></div>`;

/* ---------------------------- 5a. DASHBOARD ---------------------------- */
let sortKey = "value", sortDir = -1;
function holdingRows() {
  return state.holdings.map(h => {
    const q = state.quotes[h.symbol];
    const price = q?.price, value = price != null ? price * h.shares : null, cost = h.shares * h.avgCost;
    const income = q ? q.forwardDividend * h.shares : null;
    const g = growthFor(h.symbol);
    return { h, q, price, value, cost, pl: value != null ? value - cost : null, plp: value != null && cost ? (value - cost) / cost : null,
      day: q?.prevClose ? (price - q.prevClose) * h.shares : null, dayp: q?.prevClose ? price / q.prevClose - 1 : null,
      income, yld: q && price ? q.forwardDividend / price : null, yoc: q && h.avgCost ? q.forwardDividend / h.avgCost : null, dg: g.dg, hd: q?.growth?.div5 };
  });
}
function renderDashboard() {
  const rows = holdingRows();
  const has = rows.length > 0;
  $("#emptyHoldings").classList.toggle("show", !has);
  $("#holdingsTable").style.display = has ? "" : "none";
  const T = rows.reduce((a, r) => { a.value += r.value || 0; a.cost += r.cost; a.income += r.income || 0; a.day += r.day || 0; return a; }, { value: 0, cost: 0, income: 0, day: 0 });
  const pl = T.value - T.cost, prevVal = T.value - T.day;
  const wdg = T.income ? rows.reduce((a, r) => a + (r.income || 0) * r.dg, 0) / T.income : 0;
  $("#kpis").innerHTML = [
    kpi("Market Value", moneyC(T.value), `<span class="${cls(T.day)}">${smoney(T.day)} (${spct(prevVal ? T.day / prevVal : 0)}) today</span>`, "hl"),
    kpi("Unrealized P&L", `<span class="${cls(pl)}">${smoney(pl)}</span>`, `<span class="${cls(pl)}">${spct(T.cost ? pl / T.cost : 0)}</span> on ${moneyC(T.cost)} cost`),
    kpi("Annual Dividend Income", money(T.income), `${money(T.income / 12)} / month · ${money(T.income / 365)} / day`),
    kpi("Portfolio Yield", pct(T.value ? T.income / T.value : 0), `Yield on cost ${pct(T.cost ? T.income / T.cost : 0)}`),
    kpi("Wtd. Dividend Growth", pct(wdg, 1), "income-weighted, historical"),
  ].join("");
  const sorted = [...rows].sort((a, b) => {
    const va = sortKey === "symbol" ? a.h.symbol : (a[sortKey] ?? -Infinity), vb = sortKey === "symbol" ? b.h.symbol : (b[sortKey] ?? -Infinity);
    return (va > vb ? 1 : va < vb ? -1 : 0) * sortDir;
  });
  const cols = [["symbol", "Holding"], ["shares", "Shares"], ["avg", "Avg Cost"], ["price", "Price"], ["day", "Day Change"], ["value", "Market Value"], ["cost", "Cost Basis"], ["pl", "Unrealized P&L"], ["income", "Annual Income"], ["yld", "Yield"], ["yoc", "Yield on Cost"], ["dg", "Div Growth"], ["freq", "Pays"]];
  $("#holdingsTable").innerHTML = `<thead><tr>${cols.map(([k, l]) => `<th data-k="${k}" style="cursor:pointer">${l}${sortKey === k ? (sortDir > 0 ? " ▲" : " ▼") : ""}</th>`).join("")}</tr></thead><tbody>${sorted.map(r => `
    <tr class="clickable" data-id="${r.h.id}">
      <td><div class="sym"><span class="badge">${esc(r.h.symbol)}</span><div><div class="nm">${esc(r.q?.name || (r.q ? "" : "loading / unavailable"))}</div></div></div></td>
      <td>${shares(r.h.shares)}</td><td>${money(r.h.avgCost)}</td><td>${money(r.price)}</td>
      <td class="${cls(r.day)}">${r.day == null ? "—" : `${smoney(r.day)}<div class="small">${spct(r.dayp)}</div>`}</td>
      <td><b>${money(r.value)}</b></td><td>${money(r.cost)}</td>
      <td class="${cls(r.pl)}">${r.pl == null ? "—" : `${smoney(r.pl)}<div class="small">${spct(r.plp)}</div>`}</td>
      <td>${money(r.income)}</td><td>${pct(r.yld)}</td><td>${pct(r.yoc)}</td><td>${pct(r.dg, 1)}</td><td><span class="tag">${FREQ_LABEL[r.q?.frequency] || "—"}</span></td>
    </tr>`).join("")}</tbody>
    <tfoot><tr><td>Total (${rows.length})</td><td></td><td></td><td></td><td class="${cls(T.day)}">${smoney(T.day)}</td><td>${money(T.value)}</td><td>${money(T.cost)}</td><td class="${cls(pl)}">${smoney(pl)}</td><td>${money(T.income)}</td><td>${pct(T.value ? T.income / T.value : 0)}</td><td>${pct(T.cost ? T.income / T.cost : 0)}</td><td>${pct(wdg, 1)}</td><td></td></tr></tfoot>`;
  $("#holdingsNote").textContent = has ? "Click a row to edit · click a column to sort" : "";

  // monthly income chart (next 12 months)
  const pos = buildPositions(); const s = todayDn(), end = addYearsDn(s, 1);
  const labels = []; const d0 = dnToDate(s);
  for (let k = 0; k < 12; k++) { const m = (d0.getUTCMonth() + k) % 12, y = d0.getUTCFullYear() + Math.floor((d0.getUTCMonth() + k) / 12); labels.push(`${MONTHS[m]} ${String(y).slice(2)}`); }
  const mIndex = dn => { const d = dnToDate(dn); return (d.getUTCFullYear() - d0.getUTCFullYear()) * 12 + d.getUTCMonth() - d0.getUTCMonth(); };
  const events = [];
  const datasets = pos.map((p, i) => {
    const data = new Array(12).fill(0);
    dividendDates(p, s - 1, end).forEach(dn => { const k = mIndex(dn); const amt = p.shares * p.perPay; if (k >= 0 && k < 12) data[k] += amt; events.push({ dn, sym: p.symbol, amt, perPay: p.perPay }); });
    return { label: p.symbol, data, backgroundColor: PALETTE[i % PALETTE.length], borderRadius: 4, stack: "s" };
  });
  chart("monthlyChart", { type: "bar", data: { labels, datasets }, options: { scales: { x: { stacked: true, grid: { display: false } }, y: { ...moneyAxis, stacked: true } }, plugins: { legend: { display: pos.length <= 10, position: "bottom", labels: { usePointStyle: true, boxWidth: 8 } }, tooltip: { ...ttMoney, callbacks: { ...ttMoney.callbacks, footer: it => "Total: " + money(it.reduce((a, c) => a + c.parsed.y, 0)) } } } } });

  // allocation donut
  const mode = $("#allocMode").value;
  const al = rows.filter(r => (mode === "value" ? r.value : r.income) > 0);
  chart("allocChart", { type: "doughnut", data: { labels: al.map(r => r.h.symbol), datasets: [{ data: al.map(r => mode === "value" ? r.value : r.income), backgroundColor: al.map((_, i) => PALETTE[i % PALETTE.length]), borderColor: "#121a2f", borderWidth: 3 }] },
    options: { cutout: "66%", interaction: { mode: "nearest" }, plugins: { legend: { position: "right", labels: { usePointStyle: true, boxWidth: 8 } }, tooltip: { callbacks: { label: c => { const tot = c.dataset.data.reduce((a, b) => a + b, 0); return `${c.label}: ${money(c.parsed)} (${pct(c.parsed / tot, 1)})`; } } } } } });

  // calendar
  events.sort((a, b) => a.dn - b.dn);
  $("#calendar").innerHTML = events.slice(0, 16).map(e => { const d = dnToDate(e.dn); return `<div class="cal-item"><div class="cal-date"><span>${MONTHS[d.getUTCMonth()]}</span><b>${d.getUTCDate()}</b></div><div><div><b>${esc(e.sym)}</b></div><div class="small muted">${money(e.perPay, 4)}/sh est. ex-date</div></div><div class="cal-amt">${money(e.amt)}</div></div>`; }).join("") || `<div class="muted small">No upcoming dividends estimated.</div>`;
}

/* ---- holding modal ---- */
let editingId = null, lookupOk = null;
function openModal(h = null) {
  editingId = h?.id || null; lookupOk = h ? state.quotes[h.symbol] : null;
  $("#modalTitle").textContent = h ? `Edit ${h.symbol}` : "Add holding";
  $("#mSym").value = h?.symbol || ""; $("#mShares").value = h?.shares ?? ""; $("#mCost").value = h?.avgCost ?? "";
  $("#mDelete").style.display = h ? "" : "none";
  $("#mLookup").innerHTML = lookupOk ? lookupHtml(lookupOk) : "";
  updateModalTotal();
  $("#modalBg").classList.add("show"); setTimeout(() => (h ? $("#mShares") : $("#mSym")).focus(), 50);
}
const closeModal = () => $("#modalBg").classList.remove("show");
const lookupHtml = q => `<div class="ok"><span><b>${esc(q.name)}</b><br><span class="muted">${esc(q.exchange || "")} · ${FREQ_LABEL[q.frequency]} payer · yield ${pct(q.price ? q.forwardDividend / q.price : 0)}</span></span><span style="text-align:right"><b>${money(q.price)}</b><br><span class="muted">${money(q.forwardDividend)}/yr</span></span></div>`;
const doLookup = debounce(async () => {
  const sym = $("#mSym").value.trim().toUpperCase(); lookupOk = null;
  if (!sym) { $("#mLookup").innerHTML = ""; return; }
  $("#mLookup").innerHTML = `<span class="spinner"></span> <span class="muted">Looking up ${esc(sym)}…</span>`;
  try { const q = await fetchQuote(sym); if ($("#mSym").value.trim().toUpperCase() !== sym) return; lookupOk = q; $("#mLookup").innerHTML = lookupHtml(q); if (!$("#mCost").value) $("#mCost").value = q.price.toFixed(2); updateModalTotal(); }
  catch (e) { $("#mLookup").innerHTML = `<span class="neg">${esc(e.message)}</span>`; }
}, 450);
function updateModalTotal() {
  const sh = num($("#mShares").value), c = num($("#mCost").value);
  $("#mTotal").innerHTML = sh && c ? `Total cost basis: <b>${money(sh * c)}</b>${lookupOk ? ` · market value <b>${money(sh * lookupOk.price)}</b> · income <b>${money(sh * lookupOk.forwardDividend)}/yr</b>` : ""}` : "";
}
function saveHolding() {
  const sym = $("#mSym").value.trim().toUpperCase(), sh = num($("#mShares").value, NaN), c = num($("#mCost").value, NaN);
  if (!sym) return toast("Enter a ticker symbol", true);
  if (!(sh > 0)) return toast("Enter a positive number of shares", true);
  if (!(c >= 0)) return toast("Enter your average cost per share", true);
  if (editingId) Object.assign(state.holdings.find(h => h.id === editingId), { symbol: sym, shares: sh, avgCost: c });
  else {
    const ex = state.holdings.find(h => h.symbol === sym);
    if (ex) { const tot = ex.shares + sh; ex.avgCost = (ex.shares * ex.avgCost + sh * c) / tot; ex.shares = tot; toast(`Merged into existing ${sym} position (new avg cost ${money(ex.avgCost)})`); }
    else state.holdings.push({ id: uid(), symbol: sym, shares: sh, avgCost: c });
  }
  closeModal(); save(); renderAll();
  if (!state.quotes[sym]) fetchQuote(sym).then(() => { save(); renderAll(); }).catch(e => toast(e.message, true));
}

/* --------------------------- 5b. PROJECTIONS --------------------------- */
const FREQS = [["none", "No contributions"], ["weekly", "Weekly"], ["biweekly", "Every 2 weeks"], ["semimonthly", "Twice a month"], ["monthly", "Monthly"], ["quarterly", "Quarterly"], ["annually", "Annually"]];
const ordinal = n => n + (["th", "st", "nd", "rd"][(n % 100 - 20) % 10] || ["th", "st", "nd", "rd"][n % 100] || "th");
function planSummary(p) {
  if (p.freq === "none" || !p.amount) return "No recurring contributions.";
  const amt = money(p.amount, 0);
  const dom = p.dom === "last" ? "last day" : ordinal(+p.dom);
  const txt = { weekly: `${amt} every ${WEEKDAYS[p.weekday]}`, biweekly: `${amt} every other ${WEEKDAYS[p.weekday]}`, semimonthly: p.dom === "last" ? `${amt} on the 15th and last day of each month` : `${amt} on the ${dom} and ${ordinal(Math.min(+p.dom + 15, 31))}`, monthly: `${amt} on the ${dom} of every month`, quarterly: `${amt} on the ${dom} every 3 months`, annually: `${amt} once a year (${MONTHS[dnToDate(dnFromISO(p.start)).getUTCMonth()]} ${dom})` }[p.freq];
  const perYear = contributionDates(p, dnFromISO(p.start), addYearsDn(dnFromISO(p.start), 1) - 1).reduce((a, c) => a + c.amount, 0);
  return `${txt}, starting ${prettyDate(dnFromISO(p.start))}. ≈ <b>${money(perYear, 0)}</b> in the first year${p.stepUp ? `, rising ${p.stepUp}%/yr` : ""}.`;
}
/** Render a contribution-plan form into `box`; mutates plan and calls onChange */
function planForm(box, plan, onChange, opts = {}) {
  box.innerHTML = `<div class="form">
    ${opts.title ? `<h3>${opts.title}</h3>` : ""}
    ${opts.horizon ? `<div class="sec-t">Horizon</div><div class="seg" data-f="horizon">${[5, 10, 15, 20, 25].map(y => `<button data-v="${y}" class="${state.horizon === y ? "active" : ""}">${y}y</button>`).join("")}</div>` : ""}
    <div class="sec-t">Recurring contributions</div>
    <label>Amount per contribution ($)<input class="inp" type="number" min="0" step="10" data-f="amount" value="${plan.amount}"></label>
    <label>How often<select class="inp" data-f="freq">${FREQS.map(([v, l]) => `<option value="${v}" ${plan.freq === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
    <label data-show="dom">Day of month<select class="inp" data-f="dom">${[...Array(28)].map((_, i) => `<option value="${i + 1}" ${String(plan.dom) === String(i + 1) ? "selected" : ""}>${ordinal(i + 1)}</option>`).join("")}<option value="last" ${plan.dom === "last" ? "selected" : ""}>Last day</option></select></label>
    <label data-show="wd">Day of week<select class="inp" data-f="weekday">${WEEKDAYS.slice(1, 6).map((d, i) => `<option value="${i + 1}" ${+plan.weekday === i + 1 ? "selected" : ""}>${d}</option>`).join("")}</select></label>
    <label>First contribution on or after<input class="inp" type="date" data-f="start" value="${plan.start}"></label>
    <label>Increase contributions each year<div class="range-row"><input type="range" min="0" max="15" step="0.5" data-f="stepUp" value="${plan.stepUp}"><span class="range-val">${plan.stepUp}%</span></div></label>
    <label class="chk"><input type="checkbox" data-f="rollWeekend" ${plan.rollWeekend ? "checked" : ""}> Move weekend dates to Monday</label>
    <label>Split each contribution<select class="inp" data-f="allocMode"><option value="proportional" ${plan.allocMode === "proportional" ? "selected" : ""}>Proportional to current value</option><option value="equal" ${plan.allocMode === "equal" ? "selected" : ""}>Equally across holdings</option><option value="custom" ${plan.allocMode === "custom" ? "selected" : ""}>Custom weights${opts.customHint ? " (set in table)" : ""}</option></select></label>
    ${opts.customBox ? `<div data-custom></div>` : ""}
    <div class="helper" data-summary></div>
  </div>`;
  const vis = () => {
    const f = plan.freq;
    $("[data-show=dom]", box).style.display = ["monthly", "semimonthly", "quarterly", "annually"].includes(f) ? "" : "none";
    $("[data-show=wd]", box).style.display = ["weekly", "biweekly"].includes(f) ? "" : "none";
    $("[data-summary]", box).innerHTML = planSummary(plan);
    if (opts.customBox) renderCustomWeights($("[data-custom]", box), plan, opts.customSyms(), onChange);
  };
  box.oninput = box.onchange = e => {
    const f = e.target.dataset.f; if (!f) return;
    let v = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    if (["amount", "stepUp", "weekday"].includes(f)) v = num(v);
    if (f === "start" && !v) return;
    plan[f] = v;
    if (f === "stepUp") e.target.nextElementSibling.textContent = v + "%";
    vis(); onChange();
  };
  if (opts.horizon) $("[data-f=horizon]", box).onclick = e => { const v = e.target.dataset.v; if (!v) return; state.horizon = +v; $$("[data-f=horizon] button", box).forEach(b => b.classList.toggle("active", b === e.target)); onChange(); };
  vis();
}
function renderCustomWeights(el, plan, syms, onChange) {
  if (plan.allocMode !== "custom") { el.innerHTML = ""; return; }
  el.innerHTML = syms.map(s => `<div class="range-row small" style="margin:4px 0"><span class="badge">${esc(s)}</span><input type="range" min="0" max="100" step="1" data-w="${esc(s)}" value="${num(plan.weights[s], 0)}"><span class="range-val">${num(plan.weights[s], 0)}%</span></div>`).join("");
  el.oninput = e => { const s = e.target.dataset.w; if (!s) return; e.stopPropagation(); plan.weights[s] = num(e.target.value); e.target.nextElementSibling.textContent = e.target.value + "%"; onChange(); };
}

let projCache = null;
function runProjection() {
  const pos = buildPositions(); const tax = state.settings.tax / 100;
  if (!pos.length) return null;
  const drip = simulate(pos, state.plan, { years: 25, drip: true, tax, ledger: true });
  const nodrip = simulate(pos, state.plan, { years: 25, drip: false, tax, ledger: true });
  return projCache = { pos, drip, nodrip };
}
const scheduleProjection = debounce(() => { save(); renderProjection(false); if (currentView === "contributions") renderLedger(); }, 200);

function renderProjection(rebuildForm = true) {
  if (rebuildForm) planForm($("#planPanel"), state.plan, scheduleProjection, { horizon: true, title: "Your plan", customHint: true });
  $$("#dripSeg button").forEach(b => b.classList.toggle("active", b.dataset.v === state.dripView));
  const r = runProjection();
  if (!r) { $("#projKpis").innerHTML = ""; $("#milestoneTable").innerHTML = `<tr><td class="muted">Add holdings on the Dashboard to see projections.</td></tr>`; $("#assumpTable").innerHTML = ""; ["projIncomeChart", "projValueChart"].forEach(id => charts[id]?.destroy()); return; }
  const H = state.horizon, D = r.drip.snaps, N = r.nodrip.snaps, v = state.dripView;
  const main = v === "nodrip" ? N : D, h = main[H], h0 = main[0];
  const contribTotal = h.contributed;
  $("#projKpis").innerHTML = [
    kpi(`Annual Income in ${H}y`, money(h.fwd, 0), `${money(h.fwd / 12, 0)}/month · today ${money(h0.fwd, 0)}`, "hl"),
    kpi(`Portfolio Value in ${H}y`, moneyC(h.value), `today ${moneyC(h0.value)}`),
    kpi("New Contributions", moneyC(contribTotal), `on top of ${moneyC(r.drip.initialCost)} current cost basis`),
    kpi("Total Dividends Collected", moneyC(h.divTotal), v === "nodrip" ? `held as cash` : `reinvested via DRIP`),
    v === "compare" ? kpi("DRIP Advantage", `<span class="pos">+${money(D[H].fwd - N[H].fwd, 0)}/yr</span>`, `+${moneyC(D[H].value - N[H].value)} portfolio value`) : kpi("Yield on Cost", pct(h.yoc), "income ÷ total invested"),
  ].join("");

  const yrs = [0, 5, 10, 15, 20, 25];
  const label = y => y === 0 ? "Today" : `Year ${y}<div class="small muted">${prettyDate(D[y].dn)}</div>`;
  if (v === "compare") {
    $("#milestoneTable").innerHTML = `<thead><tr><th>Milestone</th><th>Total Invested</th><th>Value · DRIP</th><th>Value · No DRIP</th><th>Cash (No DRIP)</th><th>Annual Income · DRIP</th><th>Annual Income · No DRIP</th><th>Monthly · DRIP</th><th>Yield on Cost · DRIP</th></tr></thead><tbody>${yrs.map(y => `<tr class="${y === H ? "hl-row" : ""}"><td>${label(y)}</td><td>${money(D[y].invested, 0)}</td><td><b>${money(D[y].value, 0)}</b></td><td>${money(N[y].value, 0)}</td><td>${money(N[y].cash, 0)}</td><td class="pos"><b>${money(D[y].fwd, 0)}</b></td><td>${money(N[y].fwd, 0)}</td><td>${money(D[y].fwd / 12, 0)}</td><td>${pct(D[y].yoc)}</td></tr>`).join("")}</tbody>`;
  } else {
    $("#milestoneTable").innerHTML = `<thead><tr><th>Milestone</th><th>Total Invested</th><th>Portfolio Value</th><th>Total Gain</th><th>Annual Income</th><th>Monthly Income</th><th>Dividends That Year</th><th>Cumulative Dividends</th><th>Yield on Cost</th></tr></thead><tbody>${yrs.map(y => { const s = main[y]; const g = s.value - s.invested; return `<tr class="${y === H ? "hl-row" : ""}"><td>${label(y)}</td><td>${money(s.invested, 0)}</td><td><b>${money(s.value, 0)}</b></td><td class="${cls(g)}">${smoney(g, 0)}</td><td class="pos"><b>${money(s.fwd, 0)}</b></td><td>${money(s.fwd / 12, 0)}</td><td>${y ? money(s.divYear, 0) : "—"}</td><td>${money(s.divTotal, 0)}</td><td>${pct(s.yoc)}</td></tr>`; }).join("")}</tbody>`;
  }

  const labels = D.slice(0, H + 1).map(s => s.year === 0 ? "Now" : "Y" + s.year);
  const incomeSets = [], valueSets = [];
  if (v !== "nodrip") incomeSets.push({ label: "DRIP", data: D.slice(0, H + 1).map(s => s.fwd), backgroundColor: "#10b981", borderRadius: 4 });
  if (v !== "drip") incomeSets.push({ label: "No DRIP", data: N.slice(0, H + 1).map(s => s.fwd), backgroundColor: "#38bdf8", borderRadius: 4 });
  chart("projIncomeChart", { type: "bar", data: { labels, datasets: incomeSets }, options: { scales: { x: { grid: { display: false } }, y: moneyAxis }, plugins: { tooltip: ttMoney } } });
  if (v !== "nodrip") valueSets.push({ label: "Value · DRIP", data: D.slice(0, H + 1).map(s => s.value), borderColor: "#10b981", backgroundColor: gradientFill("projValueChart", "#10b981"), fill: true, tension: .3, pointRadius: 2 });
  if (v !== "drip") valueSets.push({ label: "Value · No DRIP (incl. cash)", data: N.slice(0, H + 1).map(s => s.value), borderColor: "#38bdf8", fill: false, tension: .3, pointRadius: 2 });
  valueSets.push({ label: "Total invested", data: D.slice(0, H + 1).map(s => s.invested), borderColor: "#8c9bba", borderDash: [5, 5], pointRadius: 0, fill: false });
  chart("projValueChart", { type: "line", data: { labels, datasets: valueSets }, options: { scales: { x: { grid: { display: false } }, y: moneyAxis }, plugins: { tooltip: ttMoney } } });

  // assumptions table
  const w = contributionWeights(state.plan, r.pos);
  const custom = state.plan.allocMode === "custom";
  $("#assumpTable").innerHTML = `<thead><tr><th>Holding</th><th>Price</th><th>Fwd Dividend</th><th>Yield</th><th>Pays</th><th>Div CAGR 3y / 5y / 10y</th><th>Price CAGR 3y / 5y / 10y</th><th>Dividend Growth Used</th><th>Price Growth Used</th><th>Contribution Split</th><th>Shares in ${H}y (DRIP)</th><th>Avg Cost in ${H}y</th></tr></thead><tbody>${r.pos.map((p, i) => {
    const q = state.quotes[p.symbol], g = growthFor(p.symbol), gr = q.growth, ps = D[H].positions[i];
    return `<tr><td><span class="badge">${esc(p.symbol)}</span></td><td>${money(p.price)}</td><td>${money(q.forwardDividend, 3)}</td><td>${pct(q.forwardDividend / p.price)}</td><td>${FREQ_LABEL[p.freq]}</td>
    <td>${pct(gr.div3, 1)} / ${pct(gr.div5, 1)} / ${pct(gr.div10, 1)}</td><td>${pct(gr.price3, 1)} / ${pct(gr.price5, 1)} / ${pct(gr.price10, 1)}</td>
    <td><input class="cell ${g.overD ? "ovr" : ""}" type="number" step="0.1" data-sym="${esc(p.symbol)}" data-k="dg" value="${(g.dg * 100).toFixed(2)}" title="Historical: ${pct(g.hd)}"> %</td>
    <td><input class="cell ${g.overP ? "ovr" : ""}" type="number" step="0.1" data-sym="${esc(p.symbol)}" data-k="pg" value="${(g.pg * 100).toFixed(2)}" title="Historical: ${pct(g.hp)}"> %</td>
    <td>${custom ? `<input class="cell" type="number" min="0" step="1" data-sym="${esc(p.symbol)}" data-k="w" value="${num(state.plan.weights[p.symbol], 0)}"> → ` : ""}${pct(w[i], 1)}</td>
    <td>${shares(ps.shares)}</td><td>${money(ps.avgCost)}</td></tr>`;
  }).join("")}</tbody>`;
}

/* ------------------------- 5c. CONTRIBUTION LEDGER ------------------------- */
let ledgerScenario = "drip", ledgerPage = 0; const PAGE = 100;
function renderLedger() {
  const r = projCache || runProjection();
  $$("#ledgerDripSeg button").forEach(b => b.classList.toggle("active", b.dataset.v === ledgerScenario));
  if (!r) { $("#ledgerKpis").innerHTML = ""; $("#ledgerTable").innerHTML = `<tr><td class="muted">Add holdings and a contribution plan to see your purchase ledger.</td></tr>`; $("#ledgerPager").innerHTML = ""; charts.basisChart?.destroy(); return; }
  const sim = ledgerScenario === "drip" ? r.drip : r.nodrip;
  const H = state.horizon, endDn = sim.snaps[H].dn;
  const buys = sim.ledger.filter(e => e.type === "buy" && e.dn <= endDn), drips = sim.ledger.filter(e => e.type === "drip" && e.dn <= endDn);
  const invested = buys.reduce((a, e) => a + e.amount, 0);
  const sel = $("#ledgerSym"); const prev = sel.value;
  sel.innerHTML = r.pos.map(p => `<option ${p.symbol === prev ? "selected" : ""}>${esc(p.symbol)}</option>`).join("");
  const sym = sel.value || r.pos[0].symbol;
  const final = sim.snaps[H].positions.find(p => p.symbol === sym);
  $("#ledgerKpis").innerHTML = [
    kpi(`Contributions (${H}y)`, buys.length ? new Set(buys.map(b => b.dn)).size.toLocaleString() : "0", planSummary(state.plan).split(".")[0], "hl"),
    kpi("Amount Contributed", moneyC(invested), `${buys.length.toLocaleString()} individual purchases`),
    kpi("DRIP Reinvested", moneyC(drips.reduce((a, e) => a + e.amount, 0)), `${drips.length.toLocaleString()} reinvestments`),
    kpi(`${sym} Avg Cost in ${H}y`, money(final?.avgCost), `projected price ${money(final?.price)}`),
  ].join("");

  // basis chart for selected symbol
  const ent = sim.ledger.filter(e => e.sym === sym && e.dn <= endDn);
  const step = Math.max(1, Math.ceil(ent.length / 400)); const pts = ent.filter((_, i) => i % step === 0 || i === ent.length - 1);
  chart("basisChart", { type: "line", data: { labels: pts.map(e => isoFromDn(e.dn)), datasets: [
    { label: "Purchase price", data: pts.map(e => e.price), borderColor: "#38bdf8", pointRadius: 0, tension: .2 },
    { label: "Running average cost basis", data: pts.map(e => e.avg), borderColor: "#10b981", backgroundColor: gradientFill("basisChart", "#10b981"), fill: true, pointRadius: 0, tension: .2 },
  ] }, options: { scales: { x: { ticks: { maxTicksLimit: 12 }, grid: { display: false } }, y: { ticks: { callback: v => money(v) } } }, plugins: { tooltip: { callbacks: { label: c => `${c.dataset.label}: ${money(c.parsed.y)}` } } } } });

  const showDrip = $("#ledgerShowDrip").checked;
  const rows = sim.ledger.filter(e => e.dn <= endDn && (showDrip || e.type === "buy"));
  const pages = Math.max(1, Math.ceil(rows.length / PAGE)); ledgerPage = clamp(ledgerPage, 0, pages - 1);
  $("#ledgerCount").textContent = `${rows.length.toLocaleString()} rows`;
  $("#ledgerTable").innerHTML = `<thead><tr><th>Date</th><th>Holding</th><th>Type</th><th>Amount</th><th>Est. Price</th><th>Shares Bought</th><th>Total Shares</th><th>Avg Cost Basis</th></tr></thead><tbody>${rows.slice(ledgerPage * PAGE, (ledgerPage + 1) * PAGE).map(e => `<tr><td>${prettyDate(e.dn)} <span class="small muted">${WEEKDAYS[weekday(e.dn)].slice(0, 3)}</span></td><td><span class="badge">${esc(e.sym)}</span></td><td><span class="tag ${e.type}">${e.type === "buy" ? "Contribution" : "DRIP"}</span></td><td>${money(e.amount)}</td><td>${money(e.price)}</td><td>${e.shares.toFixed(4)}</td><td>${e.total.toFixed(3)}</td><td><b>${money(e.avg)}</b></td></tr>`).join("")}</tbody>`;
  pager($("#ledgerPager"), ledgerPage, pages, p => { ledgerPage = p; renderLedger(); });
}
function pager(el, page, pages, go) {
  el.innerHTML = pages > 1 ? `<button class="btn btn-ghost btn-sm" data-p="0">«</button><button class="btn btn-ghost btn-sm" data-p="${page - 1}">‹</button><span>Page ${page + 1} of ${pages}</span><button class="btn btn-ghost btn-sm" data-p="${page + 1}">›</button><button class="btn btn-ghost btn-sm" data-p="${pages - 1}">»</button>` : "";
  el.onclick = e => { const p = e.target.dataset.p; if (p != null) go(clamp(+p, 0, pages - 1)); };
}
function exportLedgerCsv() {
  const r = projCache || runProjection(); if (!r) return;
  const sim = ledgerScenario === "drip" ? r.drip : r.nodrip;
  const lines = [csvRow(["date", "symbol", "type", "amount", "est_price", "shares_bought", "total_shares", "avg_cost_basis"])];
  sim.ledger.forEach(e => lines.push(csvRow([isoFromDn(e.dn), e.sym, e.type, e.amount.toFixed(2), e.price.toFixed(4), e.shares.toFixed(6), e.total.toFixed(6), e.avg.toFixed(4)])));
  downloadFile(`divcompound-ledger-${ledgerScenario}.csv`, lines.join("\n"), "text/csv");
}

/* --------------------------- 5d. WHAT-IF PORTFOLIO --------------------------- */
const scheduleHypo = debounce(() => { save(); renderHypo(false); }, 200);
function renderHypo(rebuild = true) {
  $("#hypoDrip").checked = state.hypoDrip; $("#hypoSamePlan").checked = state.hypoSamePlan;
  $("#hypoList").innerHTML = state.hypo.length ? state.hypo.map(x => {
    const q = state.quotes[x.symbol]; const val = q ? (x.mode === "shares" ? x.amount * q.price : x.amount) : null;
    return `<div class="hypo-item"><span class="badge">${esc(x.symbol)}</span><div class="grow"><div class="small"><b>${x.mode === "shares" ? shares(x.amount) + " shares" : money(x.amount, 0)}</b> ${q ? `≈ ${money(val, 0)}` : '<span class="neg">no data</span>'}</div><div class="small muted">${q ? `${pct(q.forwardDividend / q.price)} yield · +${money(val * q.forwardDividend / q.price, 0)}/yr income` : ""}</div></div><button class="x" data-del="${x.id}" title="Remove">×</button></div>`;
  }).join("") : `<div class="muted small">No additions yet. Add any ticker below — e.g. $10,000 of SCHD or 50 shares of O.</div>`;
  const plan = state.hypoSamePlan ? state.plan : state.hypoPlan;
  if (rebuild || !$("#hypoPlanBox").innerHTML) {
    if (state.hypoSamePlan) $("#hypoPlanBox").innerHTML = `<div class="helper">${planSummary(state.plan)}<br>Edit it on the Projections page, or untick the box to design a separate plan.<br><br>Note: with a proportional split, future contributions follow the <i>new</i> mix — adding a low-yield holding can lower long-run income.</div>`;
    else planForm($("#hypoPlanBox"), state.hypoPlan, scheduleHypo, { customBox: true, customSyms: () => buildPositions(state.hypo).map(p => p.symbol) });
  }
  const tax = state.settings.tax / 100, drip = state.hypoDrip, H = state.horizon;
  const cur = buildPositions(), hyp = buildPositions(state.hypo);
  if (!hyp.length) { $("#hypoKpis").innerHTML = ""; $("#hypoTable").innerHTML = `<tr><td class="muted">Add current holdings or hypothetical investments to compare.</td></tr>`; ["hypoIncomeChart", "hypoValueChart"].forEach(id => charts[id]?.destroy()); return; }
  // contributions in what-if: when using the same plan with proportional split, weights follow the new mix
  const C = cur.length ? simulate(cur, state.plan, { years: 25, drip, tax }).snaps : null;
  const W = simulate(hyp, plan, { years: 25, drip, tax }).snaps;
  const added = hyp.reduce((a, p) => a + (p.added || 0), 0);
  const c = i => C ? C[i] : { value: 0, fwd: 0, invested: 0, divTotal: 0 };
  $("#hypoKpis").innerHTML = [
    kpi("Hypothetical Capital Added", moneyC(added), `${state.hypo.length} addition${state.hypo.length === 1 ? "" : "s"}`),
    kpi("Income Today", money(W[0].fwd, 0), `${sdiff(W[0].fwd - c(0).fwd)} vs current`),
    kpi(`Income in ${H}y`, money(W[H].fwd, 0), `${sdiff(W[H].fwd - c(H).fwd)}/yr vs current · ${money(W[H].fwd / 12, 0)}/mo`, "hl"),
    kpi(`Value in ${H}y`, moneyC(W[H].value), `${sdiffC(W[H].value - c(H).value)} vs current`),
  ].join("");
  const yrs = [0, 5, 10, 15, 20, 25];
  $("#hypoTable").innerHTML = `<thead><tr><th>Milestone</th><th>Current · Value</th><th>What-If · Value</th><th>Difference</th><th>Current · Income</th><th>What-If · Income</th><th>Difference</th><th>What-If Monthly</th><th>What-If Invested</th></tr></thead><tbody>${yrs.map(y => `<tr class="${y === H ? "hl-row" : ""}"><td>${y ? "Year " + y : "Today"}</td><td>${money(c(y).value, 0)}</td><td><b>${money(W[y].value, 0)}</b></td><td>${sdiff(W[y].value - c(y).value)}</td><td>${money(c(y).fwd, 0)}</td><td class="pos"><b>${money(W[y].fwd, 0)}</b></td><td>${sdiff(W[y].fwd - c(y).fwd)}</td><td>${money(W[y].fwd / 12, 0)}</td><td>${money(W[y].invested, 0)}</td></tr>`).join("")}</tbody>`;
  const labels = W.slice(0, H + 1).map(s => s.year ? "Y" + s.year : "Now");
  chart("hypoIncomeChart", { type: "bar", data: { labels, datasets: [{ label: "Current", data: W.slice(0, H + 1).map((_, i) => c(i).fwd), backgroundColor: "#38bdf8", borderRadius: 4 }, { label: "What-If", data: W.slice(0, H + 1).map(s => s.fwd), backgroundColor: "#a78bfa", borderRadius: 4 }] }, options: { scales: { x: { grid: { display: false } }, y: moneyAxis }, plugins: { tooltip: ttMoney } } });
  chart("hypoValueChart", { type: "line", data: { labels, datasets: [{ label: "What-If", data: W.slice(0, H + 1).map(s => s.value), borderColor: "#a78bfa", backgroundColor: gradientFill("hypoValueChart", "#a78bfa"), fill: true, tension: .3, pointRadius: 2 }, { label: "Current", data: W.slice(0, H + 1).map((_, i) => c(i).value), borderColor: "#38bdf8", tension: .3, pointRadius: 2 }] }, options: { scales: { x: { grid: { display: false } }, y: moneyAxis }, plugins: { tooltip: ttMoney } } });
}
async function addHypo() {
  const sym = $("#hypoSym").value.trim().toUpperCase(), amt = num($("#hypoAmt").value, NaN), mode = $("#hypoMode").value;
  if (!sym) return toast("Enter a ticker", true);
  if (!(amt > 0)) return toast("Enter an amount greater than zero", true);
  $("#hypoMsg").innerHTML = `<span class="spinner"></span> Fetching ${esc(sym)}…`;
  try { await fetchQuote(sym); } catch (e) { $("#hypoMsg").innerHTML = `<span class="neg">${esc(e.message)}</span>`; return; }
  $("#hypoMsg").textContent = "";
  state.hypo.push({ id: uid(), symbol: sym, mode, amount: amt });
  $("#hypoSym").value = ""; $("#hypoAmt").value = "";
  save(); renderHypo();
}

/* --------------------------- 5e. HISTORICAL BACKTEST --------------------------- */
let btResult = null, btPage = 0;
function xirr(flows) { // flows: [{dn, amt}] negative = invested
  const f = r => flows.reduce((a, c) => a + c.amt / Math.pow(1 + r, (c.dn - flows[0].dn) / 365.25), 0);
  let lo = -0.99, hi = 5; if (f(lo) * f(hi) > 0) return null;
  for (let i = 0; i < 200; i++) { const m = (lo + hi) / 2; (f(lo) * f(m) <= 0) ? hi = m : lo = m; }
  return (lo + hi) / 2;
}
async function runBacktest() {
  const sym = $("#btSym").value.trim().toUpperCase(); if (!sym) return;
  const plan = { amount: num($("#btAmt").value), freq: $("#btFreq").value, dom: $("#btDom").value, weekday: num($("#btWd").value), start: $("#btStart").value, rollWeekend: false, stepUp: 0 };
  const init = num($("#btInit").value), drip = $("#btDrip").checked;
  if (!plan.start) return toast("Choose a start date", true);
  $("#btMsg").innerHTML = `<span class="spinner"></span> Loading price history…`; $("#btRun").disabled = true;
  try {
    const r = await fetch(`/api/history/${encodeURIComponent(sym)}?start=${plan.start}`); const h = await r.json();
    if (!r.ok || h.error) throw new Error(h.error || "History unavailable");
    if (!h.dates.length) throw new Error("No trading data after that start date");
    const days = h.dates.map(dnFromISO), closes = h.closes;
    const idxOnOrAfter = dn => { let lo = 0, hi = days.length; while (lo < hi) { const m = (lo + hi) >> 1; days[m] < dn ? lo = m + 1 : hi = m; } return lo; };
    const buyAt = new Map(); // trading-day index -> amount
    const add = (i, a) => { if (i < days.length) buyAt.set(i, (buyAt.get(i) || 0) + a); };
    if (init > 0) add(0, init);
    contributionDates(plan, days[0], days[days.length - 1]).forEach(c => add(idxOnOrAfter(c.dn), c.amount));
    const divAt = new Map(); h.dividends.forEach(d => { const i = idxOnOrAfter(dnFromISO(d.date)); if (i < days.length) divAt.set(i, (divAt.get(i) || 0) + d.amount); });
    let sh = 0, cb = 0, invested = 0, cash = 0, divTot = 0; const log = [], series = [], flows = [];
    let lastMonth = -1;
    for (let i = 0; i < days.length; i++) {
      const px = closes[i];
      if (divAt.has(i) && sh > 0) { // ex-date: holders of record before today receive dividend
        const amt = sh * divAt.get(i) * (1 - state.settings.tax / 100); divTot += amt;
        if (drip) { const s = amt / px; sh += s; cb += amt; log.push({ dn: days[i], type: "drip", price: px, shares: s, amount: amt, total: sh, avg: cb / sh }); } else cash += amt;
      }
      if (buyAt.has(i)) { const a = buyAt.get(i), s = a / px; sh += s; cb += a; invested += a; flows.push({ dn: days[i], amt: -a }); log.push({ dn: days[i], type: "buy", price: px, shares: s, amount: a, total: sh, avg: cb / sh }); }
      const m = dnToDate(days[i]).getUTCMonth();
      if (m !== lastMonth || i === days.length - 1) { series.push({ dn: days[i], value: sh * px + cash, invested }); lastMonth = m; }
    }
    const last = closes[closes.length - 1], value = sh * last + cash;
    flows.push({ dn: days[days.length - 1], amt: value });
    const buys = log.filter(e => e.type === "buy");
    btResult = { sym, log, series, value, invested, divTot, sh, last, cash, irr: flows.length > 1 ? xirr(flows) : null, avgBuy: buys.length ? buys.reduce((a, e) => a + e.amount, 0) / buys.reduce((a, e) => a + e.shares, 0) : 0, drip, first: days[0], lastDn: days[days.length - 1] };
    btPage = 0; $("#btMsg").textContent = ""; renderBacktest();
  } catch (e) { $("#btMsg").innerHTML = `<span class="neg">${esc(e.message)}</span>`; }
  finally { $("#btRun").disabled = false; }
}
function renderBacktest() {
  const b = btResult; if (!b) { $("#btKpis").innerHTML = ""; $("#btTable").innerHTML = `<tr><td class="muted">Configure a schedule and press <b>Run backtest</b>.</td></tr>`; return; }
  const gain = b.value - b.invested;
  $("#btKpis").innerHTML = [
    kpi("Ending Value", moneyC(b.value), `${prettyDate(b.first)} → ${prettyDate(b.lastDn)}`, "hl"),
    kpi("Total Invested", moneyC(b.invested), `${b.log.filter(e => e.type === "buy").length} purchases`),
    kpi("Total Gain", `<span class="${cls(gain)}">${smoney(gain, 0)}</span>`, `<span class="${cls(gain)}">${spct(b.invested ? gain / b.invested : 0)}</span> · annualized ${pct(b.irr)}`),
    kpi("Dividends Received", moneyC(b.divTot), b.drip ? "reinvested (DRIP)" : `held as cash`),
    kpi("Avg Purchase Price", money(b.avgBuy), `vs today ${money(b.last)} · ${shares(b.sh)} shares`),
  ].join("");
  chart("btChart", { type: "line", data: { labels: b.series.map(s => isoFromDn(s.dn).slice(0, 7)), datasets: [
    { label: "Portfolio value", data: b.series.map(s => s.value), borderColor: "#10b981", backgroundColor: gradientFill("btChart", "#10b981"), fill: true, pointRadius: 0, tension: .2 },
    { label: "Amount invested", data: b.series.map(s => s.invested), borderColor: "#8c9bba", borderDash: [5, 5], pointRadius: 0, stepped: true },
  ] }, options: { scales: { x: { ticks: { maxTicksLimit: 12 }, grid: { display: false } }, y: moneyAxis }, plugins: { tooltip: ttMoney } } });
  const pages = Math.max(1, Math.ceil(b.log.length / PAGE)); btPage = clamp(btPage, 0, pages - 1);
  $("#btTable").innerHTML = `<thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Price Paid</th><th>Shares</th><th>Total Shares</th><th>Avg Cost Basis</th><th>Gain vs Today</th></tr></thead><tbody>${b.log.slice(btPage * PAGE, (btPage + 1) * PAGE).map(e => `<tr><td>${prettyDate(e.dn)}</td><td><span class="tag ${e.type}">${e.type === "buy" ? "Contribution" : "DRIP"}</span></td><td>${money(e.amount)}</td><td>${money(e.price)}</td><td>${e.shares.toFixed(4)}</td><td>${e.total.toFixed(3)}</td><td><b>${money(e.avg)}</b></td><td class="${cls(b.last - e.price)}">${spct(b.last / e.price - 1, 1)}</td></tr>`).join("")}</tbody>`;
  pager($("#btPager"), btPage, pages, p => { btPage = p; renderBacktest(); });
}

/* --------------------------- 5f. RESEARCH --------------------------- */
async function research(sym) {
  sym = (sym || $("#resSym").value).trim().toUpperCase(); if (!sym) return;
  $("#resSym").value = sym;
  $("#resBody").innerHTML = `<div class="card"><span class="spinner"></span> Analyzing ${esc(sym)}…</div>`;
  let q; try { q = await fetchQuote(sym); } catch (e) { $("#resBody").innerHTML = `<div class="card neg">${esc(e.message)}</div>`; return; }
  const g = q.growth, gf = growthFor(sym), y = q.price ? q.forwardDividend / q.price : 0;
  const ann = q.annualDividends, thisYear = new Date().getFullYear();
  // consecutive years of growth
  let streak = 0; const full = ann.filter(a => a.year < thisYear);
  for (let i = full.length - 1; i > 0; i--) { if (full[i].amount > full[i - 1].amount * 1.0001) streak++; else break; }
  $("#resBody").innerHTML = `
    <div class="card"><div class="card-head"><div class="sym"><span class="badge" style="height:38px;font-size:14px">${esc(q.symbol)}</span><div><h3>${esc(q.name)}</h3><div class="muted small">${esc(q.exchange || "")} · ${esc(q.type || "")} · ${esc(q.currency)}</div></div></div>
      <div class="row gap"><button class="btn btn-ghost btn-sm" id="resAddHypo">✦ Add to What-If</button><button class="btn btn-primary btn-sm" id="resAdd">＋ Add to holdings</button></div></div>
      <div class="kpis" style="margin:0">${[
        kpi("Price", money(q.price), q.prevClose ? `<span class="${cls(q.price - q.prevClose)}">${spct(q.price / q.prevClose - 1)} today</span>` : ""),
        kpi("Forward Dividend", money(q.forwardDividend, 3), `TTM ${money(q.ttmDividend, 3)} · ${FREQ_LABEL[q.frequency]}`),
        kpi("Yield", pct(y), `52w ${money(q.low52)} – ${money(q.high52)}`, "hl"),
        kpi("Dividend CAGR", `${pct(g.div5, 1)} <span class="small muted">5y</span>`, `3y ${pct(g.div3, 1)} · 10y ${pct(g.div10, 1)}`),
        kpi("Price CAGR", `${pct(g.price5, 1)} <span class="small muted">5y</span>`, `3y ${pct(g.price3, 1)} · 10y ${pct(g.price10, 1)}`),
        kpi("Growth Streak", `${streak} yr${streak === 1 ? "" : "s"}`, `last ex-date ${q.lastExDate || "—"}`),
      ].join("")}</div>
      <div class="helper mt">Projection assumptions for ${esc(sym)}: dividend growth <b>${pct(gf.dg, 2)}</b>/yr, price growth <b>${pct(gf.pg, 2)}</b>/yr ${gf.overD || gf.overP ? "(includes your overrides)" : "(historical blend, capped)"}.</div>
    </div>
    <div class="grid-2">
      <div class="card"><div class="card-head"><h3>Annual Dividends &amp; Growth</h3></div><div class="chart-box"><canvas id="resAnnual"></canvas></div></div>
      <div class="card"><div class="card-head"><h3>Price History</h3></div><div class="chart-box"><canvas id="resPrice"></canvas></div></div>
    </div>
    <div class="grid-2">
      <div class="card"><div class="card-head"><h3>Individual Payments</h3><span class="muted small">last 40</span></div><div class="chart-box"><canvas id="resPays"></canvas></div></div>
      <div class="card"><div class="card-head"><h3>Year-by-Year</h3></div><div class="table-wrap" style="max-height:290px"><table class="tbl"><thead><tr><th>Year</th><th>Payments</th><th>Total / Share</th><th>Growth</th></tr></thead><tbody>${[...ann].reverse().map((a, i, arr) => { const p = arr[i + 1]; const gr = p ? a.amount / p.amount - 1 : null; const n = q.dividends.filter(d => d.date.startsWith(a.year)).length; return `<tr><td>${a.year}${a.year === thisYear ? ' <span class="tag">YTD</span>' : ""}</td><td>${n}</td><td>${money(a.amount, 4)}</td><td class="${a.year === thisYear ? "" : cls(gr)}">${a.year === thisYear ? "—" : spct(gr, 1)}</td></tr>`; }).join("")}</tbody></table></div></div>
    </div>`;
  const yrs = ann.filter(a => a.year < thisYear).slice(-20);
  chart("resAnnual", { type: "bar", data: { labels: yrs.map(a => a.year), datasets: [
    { label: "Dividends / share", data: yrs.map(a => a.amount), backgroundColor: "#10b981", borderRadius: 4, yAxisID: "y" },
    { type: "line", label: "YoY growth", data: yrs.map((a, i) => i ? (a.amount / yrs[i - 1].amount - 1) * 100 : null), borderColor: "#fbbf24", pointRadius: 3, yAxisID: "y1", tension: .3 },
  ] }, options: { scales: { x: { grid: { display: false } }, y: { ticks: { callback: v => money(v) } }, y1: { position: "right", grid: { display: false }, ticks: { callback: v => v.toFixed(0) + "%" } } }, plugins: { tooltip: { callbacks: { label: c => c.datasetIndex ? `YoY: ${c.parsed.y?.toFixed(1)}%` : `Dividends: ${money(c.parsed.y, 4)}` } } } } });
  const ph = q.priceHistory || [];
  chart("resPrice", { type: "line", data: { labels: ph.map(p => p[0].slice(0, 7)), datasets: [{ label: "Price", data: ph.map(p => p[1]), borderColor: "#38bdf8", backgroundColor: gradientFill("resPrice", "#38bdf8"), fill: true, pointRadius: 0, tension: .2 }] }, options: { scales: { x: { ticks: { maxTicksLimit: 10 }, grid: { display: false } }, y: { ticks: { callback: v => money(v) } } }, plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => money(c.parsed.y) } } } } });
  const pays = q.dividends.slice(-40);
  chart("resPays", { type: "bar", data: { labels: pays.map(d => d.date), datasets: [{ label: "Dividend", data: pays.map(d => d.amount), backgroundColor: "#a78bfa", borderRadius: 3 }] }, options: { scales: { x: { ticks: { maxTicksLimit: 8 }, grid: { display: false } }, y: { ticks: { callback: v => money(v, 3) } } }, plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => money(c.parsed.y, 4) } } } } });
  $("#resAdd").onclick = () => { openModal(); $("#mSym").value = sym; lookupOk = q; $("#mLookup").innerHTML = lookupHtml(q); $("#mCost").value = q.price.toFixed(2); };
  $("#resAddHypo").onclick = () => { showView("hypothetical"); $("#hypoSym").value = sym; $("#hypoAmt").focus(); };
}
function renderResearchQuick() {
  const el = $("#resQuick"); if (!el) return;
  const syms = state.holdings.map(h => h.symbol); const list = syms.length ? syms : ["SCHD", "O", "KO", "JEPI", "VIG", "JNJ"];
  el.innerHTML = list.map(s => `<button class="btn btn-ghost btn-sm" data-s="${esc(s)}">${esc(s)}</button>`).join("");
  el.onclick = e => e.target.dataset.s && research(e.target.dataset.s);
}

/* --------------------------- 5g. SETTINGS --------------------------- */
function renderSettings() {
  $("#setTax").value = state.settings.tax; $("#setCapDiv").value = state.settings.capDiv; $("#setCapPrice").value = state.settings.capPrice; $("#setAuto").checked = state.settings.auto; $("#setYieldCap").value = state.settings.yieldCap;
}
let autoTimer = null;
function applyAuto() { clearInterval(autoTimer); if (state.settings.auto) autoTimer = setInterval(() => refreshAll(true), 60000); }

/* ------------------------------ ROUTING ------------------------------ */
let currentView = "dashboard";
function showView(v) {
  currentView = v;
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === v));
  $$(".view").forEach(s => s.classList.toggle("active", s.id === "view-" + v));
  renderView(v); window.scrollTo(0, 0);
}
function renderView(v) {
  if (v === "dashboard") renderDashboard();
  else if (v === "projection") renderProjection();
  else if (v === "contributions") { if (!projCache) runProjection(); renderLedger(); }
  else if (v === "hypothetical") renderHypo();
  else if (v === "backtest") renderBacktest();
  else if (v === "research") renderResearchQuick();
  else if (v === "settings") renderSettings();
}
function renderAll() { projCache = null; renderView(currentView); }

/* ------------------------------ WIRING ------------------------------ */
function wire() {
  $$(".nav-item").forEach(b => b.onclick = () => showView(b.dataset.view));
  $("#refreshBtn").onclick = () => refreshAll();
  $("#addHoldingBtn").onclick = $("#emptyAddBtn").onclick = () => openModal();
  $("#demoBtn").onclick = () => {
    state.holdings = [["SCHD", 400, 24.5], ["O", 120, 54.2], ["JEPI", 90, 53.1], ["KO", 60, 58.4], ["VIG", 25, 165.0], ["MAIN", 70, 41.3]].map(([s, n, c]) => ({ id: uid(), symbol: s, shares: n, avgCost: c }));
    save(); refreshAll();
  };
  $("#holdingsTable").onclick = e => {
    const th = e.target.closest("th"); if (th) { const k = th.dataset.k; if (k === "shares" || k === "avg" || k === "freq") return; sortDir = sortKey === k ? -sortDir : -1; sortKey = k; renderDashboard(); return; }
    const tr = e.target.closest("tr[data-id]"); if (tr) openModal(state.holdings.find(h => h.id === tr.dataset.id));
  };
  $("#allocMode").onchange = renderDashboard;
  $("#mSym").oninput = doLookup; $("#mShares").oninput = $("#mCost").oninput = updateModalTotal;
  $("#mSave").onclick = saveHolding; $("#mCancel").onclick = $("#modalClose").onclick = closeModal;
  $("#modalBg").onclick = e => { if (e.target.id === "modalBg") closeModal(); };
  $("#mDelete").onclick = () => { if (!confirm("Remove this holding?")) return; state.holdings = state.holdings.filter(h => h.id !== editingId); closeModal(); save(); renderAll(); toast("Holding removed"); };
  document.addEventListener("keydown", e => { if (!$("#modalBg").classList.contains("show")) return; if (e.key === "Escape") closeModal(); if (e.key === "Enter") saveHolding(); });

  // projection
  $("#dripSeg").onclick = e => { const v = e.target.dataset.v; if (!v) return; state.dripView = v; save(); renderProjection(false); };
  $("#assumpTable").onchange = e => {
    const { sym, k } = e.target.dataset; if (!sym) return;
    const val = e.target.value === "" ? null : num(e.target.value);
    if (k === "w") state.plan.weights[sym] = val ?? 0;
    else { state.overrides[sym] = state.overrides[sym] || {}; if (val == null) delete state.overrides[sym][k]; else state.overrides[sym][k] = val / 100; }
    save(); renderProjection(false);
  };
  $("#resetAssumptions").onclick = () => { state.overrides = {}; save(); renderProjection(false); toast("Assumptions reset to historical data"); };

  // ledger
  $("#ledgerDripSeg").onclick = e => { const v = e.target.dataset.v; if (!v) return; ledgerScenario = v; ledgerPage = 0; renderLedger(); };
  $("#ledgerSym").onchange = renderLedger; $("#ledgerShowDrip").onchange = () => { ledgerPage = 0; renderLedger(); };
  $("#ledgerCsv").onclick = exportLedgerCsv;

  // hypo
  $("#hypoAdd").onclick = addHypo; $("#hypoAmt").onkeydown = $("#hypoSym").onkeydown = e => e.key === "Enter" && addHypo();
  $("#hypoList").onclick = e => { const id = e.target.dataset.del; if (!id) return; state.hypo = state.hypo.filter(x => x.id !== id); save(); renderHypo(); };
  $("#hypoDrip").onchange = e => { state.hypoDrip = e.target.checked; save(); renderHypo(false); };
  $("#hypoSamePlan").onchange = e => { state.hypoSamePlan = e.target.checked; if (!e.target.checked) state.hypoPlan = JSON.parse(JSON.stringify(state.plan)); save(); renderHypo(); };

  // backtest
  $("#btFreq").innerHTML = FREQS.slice(1).map(([v, l]) => `<option value="${v}" ${v === "monthly" ? "selected" : ""}>${l}</option>`).join("");
  $("#btDom").innerHTML = [...Array(28)].map((_, i) => `<option value="${i + 1}" ${i === 0 ? "selected" : ""}>${ordinal(i + 1)}</option>`).join("") + `<option value="last">Last day</option>`;
  $("#btWd").innerHTML = WEEKDAYS.slice(1, 6).map((d, i) => `<option value="${i + 1}">${d}</option>`).join("");
  const btVis = () => { const f = $("#btFreq").value; $(".bt-dom").style.display = ["weekly", "biweekly"].includes(f) ? "none" : ""; $(".bt-wd").style.display = ["weekly", "biweekly"].includes(f) ? "" : "none"; };
  $("#btFreq").onchange = btVis; btVis();
  $("#btRun").onclick = runBacktest;
  $("#btCsv").onclick = () => { if (!btResult) return; const L = [csvRow(["date", "type", "amount", "price", "shares", "total_shares", "avg_cost"])]; btResult.log.forEach(e => L.push(csvRow([isoFromDn(e.dn), e.type, e.amount.toFixed(2), e.price.toFixed(4), e.shares.toFixed(6), e.total.toFixed(6), e.avg.toFixed(4)]))); downloadFile(`backtest-${btResult.sym}.csv`, L.join("\n"), "text/csv"); };

  // research
  $("#resGo").onclick = () => research(); $("#resSym").onkeydown = e => e.key === "Enter" && research();

  // settings
  const setChange = () => {
    state.settings.tax = clamp(num($("#setTax").value), 0, 60); state.settings.capDiv = clamp(num($("#setCapDiv").value, 15), 0, 50); state.settings.capPrice = clamp(num($("#setCapPrice").value, 12), 0, 50); state.settings.auto = $("#setAuto").checked; state.settings.yieldCap = clamp(num($("#setYieldCap").value, 2), 0, 10);
    applyAuto(); save(); projCache = null;
  };
  ["#setTax", "#setCapDiv", "#setCapPrice", "#setAuto", "#setYieldCap"].forEach(s => $(s).onchange = setChange);
  $("#exportBtn").onclick = () => { const { quotes, ...rest } = state; downloadFile(`divcompound-portfolio-${isoFromDn(todayDn())}.json`, JSON.stringify({ app: "DivCompound", version: 1, ...rest }, null, 2), "application/json"); };
  $("#importFile").onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    try { const d = JSON.parse(await f.text()); if (!Array.isArray(d.holdings)) throw new Error("Not a DivCompound backup"); delete d.app; delete d.version; Object.assign(state, d); save(); toast(`Imported ${state.holdings.length} holdings`); refreshAll(); }
    catch (err) { toast("Import failed: " + err.message, true); } e.target.value = "";
  };
  $("#importCsvBtn").onclick = () => $("#importCsv").click();
  $("#importCsv").onchange = async e => {
    const f = e.target.files[0]; if (!f) return; let n = 0;
    (await f.text()).split(/\r?\n/).forEach(line => {
      const [s, sh, c] = line.split(/[,;\t]/).map(x => x?.trim()); if (!s || !(num(sh) > 0)) return;
      const sym = s.toUpperCase().replace(/[^A-Z0-9.\-^=]/g, ""); const ex = state.holdings.find(h => h.symbol === sym);
      if (ex) { const t = ex.shares + num(sh); ex.avgCost = (ex.shares * ex.avgCost + num(sh) * num(c)) / t; ex.shares = t; } else state.holdings.push({ id: uid(), symbol: sym, shares: num(sh), avgCost: num(c) }); n++;
    });
    e.target.value = ""; save(); toast(`Imported ${n} rows`); refreshAll();
  };
  $("#clearBtn").onclick = () => { if (!confirm("Delete all holdings, plans and settings stored in this browser?")) return; localStorage.removeItem(STORE_KEY); location.reload(); };
}

/* ------------------------------ BOOT ------------------------------ */
load(); wire(); applyAuto(); renderAll(); refreshAll(true);
